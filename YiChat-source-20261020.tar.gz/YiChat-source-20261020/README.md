# YiChat Android 2026-10-20 集成候选版

未完成全部正式验收，先阅读 VERIFICATION-ANDROID.md。

- android/：原生源码、严格构建脚本、锁/依赖校验、测试、部署回滚及资产链接配置。
- source/：基于原交接源码的最小后端/钱包/Web补充。
- android/README.md：构建与隔离联调步骤。
- 原交接README/摘要/manifest以original名称保留；原SHA仅适用于未修改的原交接包。
- 本源码包SHA256SUMS是当前文件摘要；不是发布者的独立可信签名。
- 签名私钥/密码、运行库/会话/测试账号/环境DSN未放入源码包。
