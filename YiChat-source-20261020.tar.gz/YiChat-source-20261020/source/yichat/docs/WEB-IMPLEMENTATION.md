# YiChat Web 实现说明

`client/src/chat.ts` 管理认证、原生 Rust Crypto、同步、房间登记、资料批量查询、稳定事务 Outbox、密钥备份恢复与数字 SAS 验证；`api.ts` 集中管理 SDK/业务/预览/下载请求、跨标签预算和 429 冷却。每 175ms 最多启动一个请求，服务端 uid 全设备共享 10/s 仍是最终限制；其他设备触发限流时遵守服务器等待时间。

`conversation.tsx` 提供时间线、原生回复/编辑/撤回、已读、游标历史、文字搜索、成员权限、附件和录音。历史锚点保持位置；按用户是否在底部决定滚动。消息窗口分批展开，配合 content-visibility 降低长历史绘制成本；这不是支持无限消息的完整可变高度虚拟列表。

`media.ts` 将上传串行化，遵守服务器全 uid 字节速率/租约/额度。文件先使用 Matrix 附件标准在本地加密，再上传密文；完整描述与密钥位于 Megolm 正文。SDK fetch 适配器只把允许的文件 ID 关联到外层。实际上传字节数二次检查；鉴权下载后本地校验/解密，Object URL 在组件卸载/退出时释放。HTML/SVG 等文件只下载，不在应用 origin 执行。

`previews.tsx` 仅向 `/api/preview` 提交白名单 URL 和 room，不提交整段正文。URL 消息和结构化消息均在可视时自动渲染，草稿可取消卡片。共享缓存以 UID+room+URL 隔离，限制24MiB/160项，去重并限制两笔预览并发。游戏/YCard 的 Canvas 仅在可视时挂载；离屏销毁图形资源，长期离屏释放实例数据，避免翻历史累积大量 Canvas。原游戏 SVG 和 `static/parachute-scene.js` 的纯布局函数呈现固定结果场景；活动局不提供结果。YCard 使用原 `ycards-render.js`、真实模板/实例/损耗，离屏停止材质光效更新。订单只使用认证接口的状态和 actions；可见订单由一处调度器每 20 秒合并刷新，终态停止轮询。

`dialogs.tsx` 提供订单创建确认、明确授权链接与 fund/receive/claim，赠卡确认与独立关联消息，UTC 归档下载与本地 SHA-256。业务幂等键在资产操作前持久化，不复用消息 txnId。网络结果未知保留原键/订单，不重做资产操作；消息失败只重试关联消息。

后端补充限制为：会话登记列表、可选创建请求键及票据查询、session.uid、复用原 YCards Store 的只读渲染/本人卡片接口、游戏快照标记、静态资源和浏览器所需 CSP。没有另建加密协议、钱包、资金结算或归档实现。

房间 v12 的隐式创建者权限采用 SDK 的 RoomMember.powerLevel；邀请交由 Synapse 最终授权，不重复实现该版本的权限算法。原 YIDT 授权页 CSP 精确加入聊天域名，保证批准后的可信返回跳转。

真实浏览器收款还复现并修复了成员屏障的既有问题：重复 provision 的资料更新会构造同 membership 的候选事件，被 Synapse 去重后没有持久化回调，原代码却留下永久 pending。现在仅 membership 实际变化安装资金屏障；资料更新不覆盖已有变更屏障，join/leave/ban 的事务门控仍保留，并有真实 Synapse 回归。
